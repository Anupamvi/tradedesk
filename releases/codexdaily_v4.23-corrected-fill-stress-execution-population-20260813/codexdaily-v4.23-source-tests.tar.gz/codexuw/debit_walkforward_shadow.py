from __future__ import annotations

"""Leakage-safe debit-spread research book with no execution authority.

This module deliberately lives outside the production V4.21 decision path.
It evaluates debit candidates rejected by the old debit policy without using
that policy's ``replay_guard_pass`` as training eligibility.  Promotion is
impossible unless predeclared development and untouched-holdout gates pass.
"""

import argparse
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, RobustScaler


POLICY_VERSION = "debit-walkforward-shadow-v1-20260813"
DEBIT_STRATEGIES = {"Bull Call Debit Spread", "Bear Put Debit Spread"}
NUMERIC_FEATURES = [
    "entry_dte", "debit_pct_width", "entry_quote_width_pct", "reward_risk",
    "breakeven_sigma", "iv_hv_ratio", "aligned_flow", "aligned_dp",
    "ask_bid_imbalance", "source_multileg_ratio", "source_stock_multileg_ratio",
    "log_contract_volume", "log_contract_oi", "aligned_rsi", "aligned_sma5_20",
    "aligned_price_sma20", "aligned_return5", "aligned_return20", "aligned_rs5",
    "aligned_rs20", "aligned_vwap", "atr14_pct", "volume_ratio",
]
CATEGORICAL_FEATURES = [
    "strategy", "regime", "flow_quality", "source_side_bias",
    "oi_carryover_status", "sector",
]


def _truthy(value: Any) -> bool:
    return isinstance(value, bool) and value or str(value).strip().lower() in {
        "1", "true", "yes", "y"
    }


def prepare_history(replay: pd.DataFrame, technical: pd.DataFrame) -> pd.DataFrame:
    out = replay[replay["strategy"].isin(DEBIT_STRATEGIES)].copy()
    for column in ("asof", "entry_day", "exit_day", "expiry", "next_earnings_dt"):
        out[column] = pd.to_datetime(out.get(column), errors="coerce")
    technical = technical.copy()
    technical["date"] = pd.to_datetime(technical["date"], errors="coerce")
    out = out.merge(
        technical,
        left_on=["asof", "ticker"],
        right_on=["date", "ticker"],
        how="left",
        suffixes=("", "_technical"),
    )
    numeric = set(NUMERIC_FEATURES) | {
        "stock_price_entry", "entry_debit", "long_strike_eod", "iv30d",
        "entry_width", "combined_flow_bias", "dp_directional_ratio",
        "source_contract_volume", "source_contract_oi", "source_ask_side_volume",
        "source_bid_side_volume", "exit_value", "rsi14", "sma5", "sma20",
        "close", "return5", "return20", "relative_strength5",
        "relative_strength20", "vwap20",
    }
    for column in numeric:
        if column in out.columns:
            out[column] = pd.to_numeric(out[column], errors="coerce")

    bull = out["strategy"].eq("Bull Call Debit Spread")
    sign = np.where(bull, 1.0, -1.0)
    breakeven = np.where(
        bull,
        out["long_strike_eod"] + out["entry_debit"],
        out["long_strike_eod"] - out["entry_debit"],
    )
    implied_move = (
        out["stock_price_entry"] * out["iv30d"]
        * np.sqrt(out["entry_dte"] / 365.0)
    )
    out["breakeven_sigma"] = (
        pd.Series(breakeven, index=out.index) - out["stock_price_entry"]
    ).abs() / implied_move.replace(0, np.nan)
    out["debit_pct_width"] = out["entry_debit"] / out["entry_width"]
    out["earnings_known"] = out["next_earnings_dt"].notna()
    out["earnings_crosses"] = out["earnings_known"] & out["next_earnings_dt"].between(
        out["entry_day"], out["expiry"]
    )
    out["aligned_flow"] = out["combined_flow_bias"] * sign
    out["aligned_dp"] = out["dp_directional_ratio"] * sign
    out["aligned_rsi"] = (out["rsi14"] - 50.0) * sign
    out["aligned_sma5_20"] = (out["sma5"] / out["sma20"] - 1.0) * sign
    out["aligned_price_sma20"] = (out["close"] / out["sma20"] - 1.0) * sign
    out["aligned_return5"] = out["return5"] * sign
    out["aligned_return20"] = out["return20"] * sign
    out["aligned_rs5"] = out["relative_strength5"] * sign
    out["aligned_rs20"] = out["relative_strength20"] * sign
    out["aligned_vwap"] = (out["close"] / out["vwap20"] - 1.0) * sign
    denominator = (out["source_ask_side_volume"] + out["source_bid_side_volume"]).replace(0, np.nan)
    out["ask_bid_imbalance"] = (
        (out["source_ask_side_volume"] - out["source_bid_side_volume"]) / denominator * sign
    )
    out["log_contract_volume"] = np.log1p(out["source_contract_volume"].clip(lower=0))
    out["log_contract_oi"] = np.log1p(out["source_contract_oi"].clip(lower=0))
    out["stress_pnl_10pct"] = (out["exit_value"] - out["entry_debit"] * 1.10) * 100.0
    out["stress_win_10pct"] = (out["stress_pnl_10pct"] > 0).astype(int)
    out[NUMERIC_FEATURES] = out[NUMERIC_FEATURES].replace([np.inf, -np.inf], np.nan)
    return out


def learning_guard(frame: pd.DataFrame) -> pd.Series:
    integrity = (
        frame["exact_evaluated"].map(_truthy)
        & frame["entry_debit"].gt(0)
        & frame["entry_width"].gt(0)
        & frame["exit_value"].notna()
        & frame["entry_day"].notna()
        & frame["exit_day"].ge(frame["entry_day"])
    )
    return (
        integrity & frame["earnings_known"] & ~frame["earnings_crosses"]
        & frame["entry_dte"].between(4, 75)
        & frame["debit_pct_width"].between(0.02, 0.80)
        & frame["entry_quote_width_pct"].le(0.60)
        & frame["reward_risk"].ge(0.25)
        & frame["breakeven_sigma"].le(1.50)
        & frame["iv_hv_ratio"].between(0.25, 2.50)
    )


def candidate_guard(frame: pd.DataFrame) -> pd.Series:
    return (
        learning_guard(frame)
        & frame["entry_dte"].between(14, 60)
        & frame["debit_pct_width"].between(0.05, 0.65)
        & frame["entry_quote_width_pct"].le(0.40)
        & frame["reward_risk"].ge(1.00)
        & frame["breakeven_sigma"].le(1.00)
        & frame["iv_hv_ratio"].between(0.50, 1.50)
    )


def _model() -> Pipeline:
    transformer = ColumnTransformer([
        ("numeric", Pipeline([
            ("impute", SimpleImputer(strategy="median")),
            ("scale", RobustScaler()),
        ]), NUMERIC_FEATURES),
        ("categorical", Pipeline([
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("encode", OneHotEncoder(handle_unknown="ignore")),
        ]), CATEGORICAL_FEATURES),
    ], sparse_threshold=0.0)
    return Pipeline([
        ("features", transformer),
        ("model", LogisticRegression(C=0.10, max_iter=3000, solver="liblinear")),
    ])


def _predict_probabilities(model: Pipeline, frame: pd.DataFrame) -> np.ndarray:
    """Score without the noisy sparse-BLAS path in older local sklearn builds."""
    transformed = np.asarray(
        model.named_steps["features"].transform(frame),
        dtype=float,
    )
    estimator = model.named_steps["model"]
    coefficients = np.asarray(estimator.coef_[0], dtype=float)
    logits = np.einsum("ij,j->i", transformed, coefficients) + float(estimator.intercept_[0])
    logits = np.clip(logits, -50.0, 50.0)
    return 1.0 / (1.0 + np.exp(-logits))


def walk_forward_predictions(frame: pd.DataFrame, *, min_prior: int = 100) -> pd.DataFrame:
    learn = frame[learning_guard(frame)].sort_values(["asof", "ticker", "strategy"])
    candidates = frame[candidate_guard(frame)]
    records: list[pd.DataFrame] = []
    for month, test in candidates.groupby(candidates["asof"].dt.to_period("M"), sort=True):
        prior = learn[learn["exit_day"] < month.start_time]
        if len(prior) < min_prior or prior["stress_win_10pct"].nunique() < 2:
            continue
        model = _model()
        model.fit(prior[NUMERIC_FEATURES + CATEGORICAL_FEATURES], prior["stress_win_10pct"])
        scored = test.copy()
        scored["predicted_win_probability"] = _predict_probabilities(
            model,
            scored[NUMERIC_FEATURES + CATEGORICAL_FEATURES],
        )
        probability = scored["predicted_win_probability"]
        scored["predicted_ev_1x"] = (
            probability * (scored["entry_width"] - scored["entry_debit"])
            - (1.0 - probability) * scored["entry_debit"]
        ) * 100.0
        scored["prior_sample_size"] = len(prior)
        records.append(scored)
    return pd.concat(records, ignore_index=True) if records else pd.DataFrame()


def metrics(frame: pd.DataFrame) -> dict[str, Any]:
    if frame.empty:
        return {"n": 0, "wins": 0, "win_rate": None, "profit_factor": None,
                "pnl": 0.0, "max_drawdown": 0.0, "positive_month_ratio": None}
    pnl = frame["stress_pnl_10pct"].astype(float)
    gross_loss = -float(pnl[pnl < 0].sum())
    equity = pnl.cumsum()
    monthly = frame.assign(month=frame["asof"].dt.to_period("M").astype(str)).groupby(
        "month"
    )["stress_pnl_10pct"].sum()
    return {
        "n": int(len(frame)), "wins": int((pnl > 0).sum()),
        "win_rate": float((pnl > 0).mean()),
        "profit_factor": float(pnl[pnl > 0].sum() / gross_loss) if gross_loss else None,
        "pnl": float(pnl.sum()),
        "max_drawdown": float((equity - equity.cummax()).min()),
        "positive_month_ratio": float((monthly > 0).mean()),
    }


def breakdown_metrics(frame: pd.DataFrame) -> dict[str, Any]:
    if frame.empty:
        return {"by_month": {}, "by_strategy": {}}
    by_month = {
        str(month): metrics(group)
        for month, group in frame.groupby(frame["asof"].dt.to_period("M"), sort=True)
    }
    by_strategy = (
        {
            str(strategy): metrics(group)
            for strategy, group in frame.groupby("strategy", sort=True)
        }
        if "strategy" in frame.columns
        else {}
    )
    return {"by_month": by_month, "by_strategy": by_strategy}


def select_book(predictions: pd.DataFrame, threshold: float) -> pd.DataFrame:
    if predictions.empty:
        return predictions.copy()
    eligible = predictions[
        predictions["predicted_win_probability"].ge(threshold)
        & predictions["predicted_ev_1x"].gt(0)
    ].copy()
    return eligible.sort_values(
        ["asof", "predicted_win_probability", "predicted_ev_1x", "breakeven_sigma"],
        ascending=[True, False, False, True],
    ).groupby("asof", as_index=False).head(1)


def evaluate(frame: pd.DataFrame, *, cutoff: object, threshold: float = 0.65) -> tuple[pd.DataFrame, dict[str, Any]]:
    cutoff_dt = pd.Timestamp(cutoff)
    development = select_book(frame[frame["asof"] < cutoff_dt], threshold)
    holdout = select_book(frame[frame["asof"] >= cutoff_dt], threshold)
    development_metrics = metrics(development)
    holdout_metrics = metrics(holdout)
    blockers: list[str] = []
    if development_metrics["n"] < 20: blockers.append("development_sample_below_20")
    if holdout_metrics["n"] < 15: blockers.append("holdout_sample_below_15")
    for name, result in (("development", development_metrics), ("holdout", holdout_metrics)):
        if result["profit_factor"] is None or result["profit_factor"] < 1.25:
            blockers.append(f"{name}_stress_pf_below_1.25")
        if result["positive_month_ratio"] is None or result["positive_month_ratio"] < 0.67:
            blockers.append(f"{name}_positive_month_ratio_below_0.67")
        if result["max_drawdown"] < -603.50:
            blockers.append(f"{name}_drawdown_worse_than_v4.21")
    summary = {
        "policy_version": POLICY_VERSION,
        "status": "PASS" if not blockers else "RESEARCH_ONLY",
        "execution_authorized": False,
        "threshold": threshold,
        "cutoff": cutoff_dt.date().isoformat(),
        "development": development_metrics,
        "holdout": holdout_metrics,
        "development_breakdown": breakdown_metrics(development),
        "holdout_breakdown": breakdown_metrics(holdout),
        "blockers": blockers,
        "note": "Shadow evidence only; production V4.21 behavior is unchanged.",
    }
    return pd.concat([development, holdout], ignore_index=True), summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replay", required=True, type=Path)
    parser.add_argument("--technical", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--cutoff", default="2026-05-01")
    parser.add_argument("--threshold", default=0.65, type=float)
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    history = prepare_history(
        pd.read_csv(args.replay, low_memory=False),
        pd.read_csv(args.technical, low_memory=False),
    )
    predictions = walk_forward_predictions(history)
    selected, summary = evaluate(predictions, cutoff=args.cutoff, threshold=args.threshold)
    predictions.to_csv(args.out_dir / "debit_walkforward_predictions.csv", index=False)
    selected.to_csv(args.out_dir / "debit_walkforward_selected.csv", index=False)
    (args.out_dir / "debit_walkforward_summary.json").write_text(
        json.dumps(summary, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(summary, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
