import pandas as pd

from codexuw.debit_walkforward_shadow import candidate_guard, evaluate, select_book


def test_candidate_guard_does_not_depend_on_old_replay_policy() -> None:
    row = {
        "exact_evaluated": True, "entry_debit": 1.0, "entry_width": 5.0,
        "exit_value": 2.0, "entry_day": pd.Timestamp("2026-01-02"),
        "exit_day": pd.Timestamp("2026-01-05"), "earnings_known": True,
        "earnings_crosses": False, "entry_dte": 30, "debit_pct_width": 0.20,
        "entry_quote_width_pct": 0.10, "reward_risk": 4.0,
        "breakeven_sigma": 0.50, "iv_hv_ratio": 1.00,
        "replay_guard_pass": False,
    }
    assert bool(candidate_guard(pd.DataFrame([row])).iloc[0])


def test_select_book_keeps_one_highest_probability_per_day() -> None:
    frame = pd.DataFrame([
        {"asof": pd.Timestamp("2026-01-02"), "ticker": "A", "predicted_win_probability": .70,
         "predicted_ev_1x": 20.0, "breakeven_sigma": .5},
        {"asof": pd.Timestamp("2026-01-02"), "ticker": "B", "predicted_win_probability": .80,
         "predicted_ev_1x": 10.0, "breakeven_sigma": .4},
    ])
    selected = select_book(frame, .65)
    assert selected["ticker"].tolist() == ["B"]


def test_evaluate_never_grants_execution_authority_when_gates_fail() -> None:
    frame = pd.DataFrame([
        {"asof": pd.Timestamp("2026-04-01"), "predicted_win_probability": .70,
         "predicted_ev_1x": 20.0, "breakeven_sigma": .5, "stress_pnl_10pct": 50.0},
        {"asof": pd.Timestamp("2026-06-01"), "predicted_win_probability": .70,
         "predicted_ev_1x": 20.0, "breakeven_sigma": .5, "stress_pnl_10pct": -50.0},
    ])
    _, summary = evaluate(frame, cutoff="2026-05-01")
    assert summary["status"] == "RESEARCH_ONLY"
    assert summary["execution_authorized"] is False
